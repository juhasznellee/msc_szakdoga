/* 
-*- coding: latin-1 -*-

This file is part of RefactorErl.

RefactorErl is free software: you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published
by the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

RefactorErl is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License
along with RefactorErl.  If not, see <http://plc.inf.elte.hu/erlang/>.

The Original Code is RefactorErl.

The Initial Developer of the Original Code is Eötvös Loránd University.
Portions created  by Eötvös Loránd University and ELTE-Soft Ltd.
are Copyright 2007-2024 Eötvös Loránd University, ELTE-Soft Ltd.
and Ericsson Hungary. All Rights Reserved.
*/

package com.refactorerl.ui.presentation.dependency;

import org.eclipse.osgi.util.NLS;

public class Messages extends NLS {
	private static final String BUNDLE_NAME = "com.refactorerl.ui.presentation.dependency.messages"; //$NON-NLS-1$
	public static String BrowserView_0;
	public static String ControlPanel_0;
	public static String ControlPanel_1;
	public static String ControlPanel_10;
	public static String ControlPanel_11;
	public static String ControlPanel_2;
	public static String ControlPanel_3;
	public static String ControlPanel_4;
	public static String ControlPanel_5;
	public static String DrawDepView_1;
	public static String DrawDepView_10;
	public static String DrawDepView_11;
	public static String DrawDepView_12;
	public static String DrawDepView_13;
	public static String DrawDepView_14;
	public static String DrawDepView_15;
	public static String DrawDepView_16;
	public static String DrawDepView_18;
	public static String DrawDepView_19;
	public static String DrawDepView_2;
	public static String DrawDepView_3;
	public static String DrawDepView_4;
	public static String DrawDepView_5;
	public static String DrawDepView_6;
	public static String DrawDepView_7;
	public static String DrawDepView_8;
	public static String DrawDepView_9;
	public static String FunctionControlPanel_0;
	public static String FunctionControlPanel_1;
	public static String FunctionControlPanel_2;
	public static String GraphvizSupport_14;
	public static String GraphvizSupport_2;
	public static String GraphvizSupport_3;
	public static String GraphvizSupport_5;
	public static String GraphvizSupport_6;
	public static String GraphvizSupport_8;
	public static String GraphvizSupport_9;
	public static String ImageView_0;
	public static String ImageView_1;
	public static String ModuleBlockControlPanel_0;
	public static String ModuleBlockControlPanel_1;
	public static String ModuleBlockControlPanel_4;
	public static String ModuleBlockControlPanel_5;
	public static String ModuleBlockControlPanel_6;
	public static String ModuleBlockControlPanel_7;
	public static String ModuleBlockControlPanel_8;
	public static String ModuleBlockControlPanel_9;
	public static String ModuleControlPanel_0;
	public static String ModuleControlPanel_1;
	public static String ModuleControlPanel_2;
	public static String ModuleFunctionControlPanel_0;
	static {
		// initialize resource bundle
		NLS.initializeMessages(BUNDLE_NAME, Messages.class);
	}

	private Messages() {
	}
}
