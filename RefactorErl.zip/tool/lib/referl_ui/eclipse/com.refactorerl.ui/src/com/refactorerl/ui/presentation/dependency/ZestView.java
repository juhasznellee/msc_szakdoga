/* 
-*- coding: latin-1 -*-

This file is part of RefactorErl.

RefactorErl is free software: you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published
by the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

RefactorErl is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License
along with RefactorErl.  If not, see <http://plc.inf.elte.hu/erlang/>.

The Original Code is RefactorErl.

The Initial Developer of the Original Code is Eötvös Loránd University.
Portions created  by Eötvös Loránd University and ELTE-Soft Ltd.
are Copyright 2007-2024 Eötvös Loránd University, ELTE-Soft Ltd.
and Ericsson Hungary. All Rights Reserved.
*/

package com.refactorerl.ui.presentation.dependency;

import java.io.File;


//import org.eclipse.gef4.zest.core.widgets.Graph;
//import org.eclipse.gef4.zest.internal.dot.DotExport;
//import org.eclipse.gef4.zest.internal.dot.DotImport;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.ui.part.ViewPart;
 
public class ZestView extends ViewPart { 
	// NOTE disabled until gef4 plugin integration 

	private Composite parent;

	@Override
	public void createPartControl(Composite parent) {
		this.parent = parent;

	}

	public void showDotByFile(String filePath) {
//		for (Control c : parent.getChildren()) {
//			c.dispose();
//		}
//
//		File f = new File(filePath);
//
//		Graph graph = new DotImport(f).newGraphInstance(parent, SWT.NONE);
//
//		System.out.println(new DotExport(graph).toDotString());

	}

	public void showDotByDefinition(String definition, String name) {
//		setPartName(name);
//		
//		for (Control c : parent.getChildren()) {
//			c.dispose();
//		}
//
//		 Graph graph = new DotImport(
//		 definition).newGraphInstance(parent, SWT.NONE);
//		 
//		 parent.layout();


	}

	@Override
	public void setFocus() {
	
	}

}
