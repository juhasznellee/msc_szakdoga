/* 
-*- coding: latin-1 -*-

This file is part of RefactorErl.

RefactorErl is free software: you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published
by the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

RefactorErl is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License
along with RefactorErl.  If not, see <http://plc.inf.elte.hu/erlang/>.

The Original Code is RefactorErl.

The Initial Developer of the Original Code is Eötvös Loránd University.
Portions created  by Eötvös Loránd University and ELTE-Soft Ltd.
are Copyright 2007-2024 Eötvös Loránd University, ELTE-Soft Ltd.
and Ericsson Hungary. All Rights Reserved.
*/

package com.refactorerl.ui.presentation.refactoring;

import org.eclipse.osgi.util.NLS;

public class Messages extends NLS {
	private static final String BUNDLE_NAME = "com.refactorerl.ui.presentation.refactoring.messages"; //$NON-NLS-1$
	public static String RefactoringContributionItem_10;
	public static String RefactoringContributionItem_11;
	public static String RefactoringContributionItem_12;
	public static String RefactoringContributionItem_13;
	public static String RefactoringContributionItem_14;
	public static String RefactoringContributionItem_15;
	public static String RefactoringContributionItem_16;
	public static String RefactoringContributionItem_17;
	public static String RefactoringContributionItem_18;
	public static String RefactoringContributionItem_19;
	public static String RefactoringContributionItem_20;
	public static String RefactoringContributionItem_21;
	public static String RefactoringContributionItem_22;
	public static String RefactoringContributionItem_23;
	public static String RefactoringContributionItem_24;
	public static String RefactoringContributionItem_25;
	public static String RefactoringContributionItem_26;
	public static String RefactoringContributionItem_27;
	public static String RefactoringContributionItem_28;
	public static String RefactoringContributionItem_29;
	public static String RefactoringContributionItem_30;
	public static String RefactoringContributionItem_31;
	public static String RefactoringContributionItem_32;
	public static String RefactoringContributionItem_33;
	public static String RefactoringContributionItem_34;
	public static String RefactoringContributionItem_7;
	public static String RefactoringContributionItem_8;
	public static String RefactoringContributionItem_9;
	public static String RefactoringHandler_0;
	public static String RefactoringHandler_1;
	public static String RefactoringHandler_100;
	public static String RefactoringHandler_101;
	public static String RefactoringHandler_102;
	public static String RefactoringHandler_103;
	public static String RefactoringHandler_104;
	public static String RefactoringHandler_105;
	public static String RefactoringHandler_106;
	public static String RefactoringHandler_107;
	public static String RefactoringHandler_108;
	public static String RefactoringHandler_109;
	public static String RefactoringHandler_110;
	public static String RefactoringHandler_111;
	public static String RefactoringHandler_113;
	public static String RefactoringHandler_114;
	public static String RefactoringHandler_115;
	public static String RefactoringHandler_116;
	public static String RefactoringHandler_117;
	public static String RefactoringHandler_118;
	public static String RefactoringHandler_119;
	public static String RefactoringHandler_12;
	public static String RefactoringHandler_120;
	public static String RefactoringHandler_123;
	public static String RefactoringHandler_124;
	public static String RefactoringHandler_125;
	public static String RefactoringHandler_127;
	public static String RefactoringHandler_129;
	public static String RefactoringHandler_130;
	public static String RefactoringHandler_131;
	public static String RefactoringHandler_132;
	public static String RefactoringHandler_133;
	public static String RefactoringHandler_134;
	public static String RefactoringHandler_135;
	public static String RefactoringHandler_136;
	public static String RefactoringHandler_137;
	public static String RefactoringHandler_138;
	public static String RefactoringHandler_139;
	public static String RefactoringHandler_14;
	public static String RefactoringHandler_140;
	public static String RefactoringHandler_141;
	public static String RefactoringHandler_145;
	public static String RefactoringHandler_148;
	public static String RefactoringHandler_149;
	public static String RefactoringHandler_151;
	public static String RefactoringHandler_153;
	public static String RefactoringHandler_154;
	public static String RefactoringHandler_156;
	public static String RefactoringHandler_158;
	public static String RefactoringHandler_159;
	public static String RefactoringHandler_16;
	public static String RefactoringHandler_17;
	public static String RefactoringHandler_19;
	public static String RefactoringHandler_20;
	public static String RefactoringHandler_23;
	public static String RefactoringHandler_25;
	public static String RefactoringHandler_27;
	public static String RefactoringHandler_28;
	public static String RefactoringHandler_29;
	public static String RefactoringHandler_30;
	public static String RefactoringHandler_31;
	public static String RefactoringHandler_32;
	public static String RefactoringHandler_33;
	public static String RefactoringHandler_34;
	public static String RefactoringHandler_35;
	public static String RefactoringHandler_36;
	public static String RefactoringHandler_37;
	public static String RefactoringHandler_38;
	public static String RefactoringHandler_42;
	public static String RefactoringHandler_43;
	public static String RefactoringHandler_44;
	public static String RefactoringHandler_45;
	public static String RefactoringHandler_46;
	public static String RefactoringHandler_47;
	public static String RefactoringHandler_48;
	public static String RefactoringHandler_49;
	public static String RefactoringHandler_5;
	public static String RefactoringHandler_50;
	public static String RefactoringHandler_51;
	public static String RefactoringHandler_52;
	public static String RefactoringHandler_53;
	public static String RefactoringHandler_54;
	public static String RefactoringHandler_55;
	public static String RefactoringHandler_56;
	public static String RefactoringHandler_57;
	public static String RefactoringHandler_58;
	public static String RefactoringHandler_59;
	public static String RefactoringHandler_6;
	public static String RefactoringHandler_60;
	public static String RefactoringHandler_61;
	public static String RefactoringHandler_62;
	public static String RefactoringHandler_63;
	public static String RefactoringHandler_64;
	public static String RefactoringHandler_65;
	public static String RefactoringHandler_66;
	public static String RefactoringHandler_67;
	public static String RefactoringHandler_68;
	public static String RefactoringHandler_69;
	public static String RefactoringHandler_70;
	public static String RefactoringHandler_71;
	public static String RefactoringHandler_72;
	public static String RefactoringHandler_73;
	public static String RefactoringHandler_74;
	public static String RefactoringHandler_75;
	public static String RefactoringHandler_76;
	public static String RefactoringHandler_77;
	public static String RefactoringHandler_78;
	public static String RefactoringHandler_83;
	public static String RefactoringHandler_84;
	public static String RefactoringHandler_86;
	public static String RefactoringHandler_88;
	public static String RefactoringHandler_89;
	public static String RefactoringHandler_90;
	public static String RefactoringHandler_91;
	public static String RefactoringHandler_92;
	public static String RefactoringHandler_93;
	public static String RefactoringHandler_94;
	public static String RefactoringHandler_95;
	public static String RefactoringHandler_96;
	public static String RefactoringHandler_97;
	public static String RefactoringHandler_98;
	public static String RefactoringHandler_99;
	static {
		// initialize resource bundle
		NLS.initializeMessages(BUNDLE_NAME, Messages.class);
	}

	private Messages() {
	}
}
