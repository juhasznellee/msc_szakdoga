package com.refactorerl.ui.communication.process;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public interface IOHandler {
	public void open(InputStream fromProcessStream,
			InputStream errorFromProcessStream, OutputStream toProcessStream);

	public void close() throws IOException;
}
