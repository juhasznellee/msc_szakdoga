/* 
-*- coding: latin-1 -*-

This file is part of RefactorErl.

RefactorErl is free software: you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published
by the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

RefactorErl is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License
along with RefactorErl.  If not, see <http://plc.inf.elte.hu/erlang/>.

The Original Code is RefactorErl.

The Initial Developer of the Original Code is Eötvös Loránd University.
Portions created  by Eötvös Loránd University and ELTE-Soft Ltd.
are Copyright 2007-2024 Eötvös Loránd University, ELTE-Soft Ltd.
and Ericsson Hungary. All Rights Reserved.
*/

package com.refactorerl.ui.presentation.filelist;

import org.eclipse.osgi.util.NLS;

public class Messages extends NLS {
	private static final String BUNDLE_NAME = "com.refactorerl.ui.presentation.filelist.messages"; //$NON-NLS-1$
	public static String DelEnvHandler_0;
	public static String DelEnvHandler_1;
	public static String DelEnvHandler_2;
	public static String DelEnvHandler_3;
	public static String DelEnvHandler_4;
	public static String DelEnvHandler_5;
	public static String DropFileHandler_4;
	public static String DropFileHandler_5;
	public static String DropFileHandler_6;
	public static String DropFileHandler_7;
	public static String EnvsView_0;
	public static String EnvsView_1;
	public static String FileListView_0;
	public static String ResetDbHandler_0;
	public static String ResetDbHandler_1;
	public static String ResetDbHandler_2;
	static {
		// initialize resource bundle
		NLS.initializeMessages(BUNDLE_NAME, Messages.class);
	}

	private Messages() {
	}
}
