/* 
-*- coding: latin-1 -*-

This file is part of RefactorErl.

RefactorErl is free software: you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published
by the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

RefactorErl is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License
along with RefactorErl.  If not, see <http://plc.inf.elte.hu/erlang/>.

The Original Code is RefactorErl.

The Initial Developer of the Original Code is Eötvös Loránd University.
Portions created  by Eötvös Loránd University and ELTE-Soft Ltd.
are Copyright 2007-2024 Eötvös Loránd University, ELTE-Soft Ltd.
and Ericsson Hungary. All Rights Reserved.
*/

package com.refactorerl.ui.presentation;

import org.eclipse.osgi.util.NLS;

public class Messages extends NLS {
	private static final String BUNDLE_NAME = "com.refactorerl.ui.presentation.messages"; //$NON-NLS-1$
	public static String Activator_1;
	public static String Activator_15;
	public static String Activator_16;
	public static String Activator_17;
	public static String Activator_18;
	public static String Activator_22;
	public static String Activator_23;
	public static String Activator_24;
	public static String Activator_29;
	public static String Activator_3;
	public static String Activator_30;
	public static String Activator_31;
	public static String Activator_32;
	public static String Activator_35;
	public static String Activator_36;
	public static String Activator_37;
	public static String Activator_4;
	public static String Activator_40;
	public static String Activator_41;
	public static String Activator_42;
	public static String Activator_5;
	public static String StatusBarEventHandler_0;
	public static String WorkbenchPreferencePage_0;
	public static String WorkbenchPreferencePage_10;
	public static String WorkbenchPreferencePage_13;
	public static String WorkbenchPreferencePage_14;
	public static String WorkbenchPreferencePage1_0;
	public static String WorkbenchPreferencePage1_1;
	public static String WorkbenchPreferencePage1_13;
	public static String WorkbenchPreferencePage1_15;
	public static String WorkbenchPreferencePage1_16;
	public static String WorkbenchPreferencePage1_18;
	public static String WorkbenchPreferencePage1_2;
	public static String WorkbenchPreferencePage1_20;
	public static String WorkbenchPreferencePage1_21;
	public static String WorkbenchPreferencePage1_23;
	public static String WorkbenchPreferencePage1_3;
	public static String WorkbenchPreferencePage1_31;
	public static String WorkbenchPreferencePage1_5;
	public static String WorkbenchPreferencePage1_50;
	public static String WorkbenchPreferencePage1_51;
	public static String WorkbenchPreferencePage1_52;
	public static String WorkbenchPreferencePage1_6;
	public static String WorkbenchPreferencePage1_8;
	static {
		// initialize resource bundle
		NLS.initializeMessages(BUNDLE_NAME, Messages.class);
	}

	private Messages() {
	}
}
