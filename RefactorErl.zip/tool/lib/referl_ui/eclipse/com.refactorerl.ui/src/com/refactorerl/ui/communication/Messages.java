/* 
-*- coding: latin-1 -*-

This file is part of RefactorErl.

RefactorErl is free software: you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published
by the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

RefactorErl is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License
along with RefactorErl.  If not, see <http://plc.inf.elte.hu/erlang/>.

The Original Code is RefactorErl.

The Initial Developer of the Original Code is Eötvös Loránd University.
Portions created  by Eötvös Loránd University and ELTE-Soft Ltd.
are Copyright 2007-2024 Eötvös Loránd University, ELTE-Soft Ltd.
and Ericsson Hungary. All Rights Reserved.
*/

package com.refactorerl.ui.communication;

import org.eclipse.osgi.util.NLS;

public class Messages extends NLS {
	private static final String BUNDLE_NAME = "com.refactorerl.ui.communication.messages"; //$NON-NLS-1$
	public static String MessageParseHelper_21;
	public static String MessageParseHelper_23;
	public static String MessageParseHelper_27;
	public static String MessageParseHelper_7;
	public static String MessageParseHelper_8;
	public static String MessageParseHelper_9;
	public static String ReferlProxy_0;
	public static String ReferlProxy_1;
	public static String ReferlProxy_13;
	public static String ReferlProxy_14;
	public static String ReferlProxy_15;
	public static String ReferlProxy_16;
	public static String ReferlProxy_17;
	public static String ReferlProxy_18;
	public static String ReferlProxy_19;
	public static String ReferlProxy_20;
	public static String ReferlProxy_21;
	public static String ReferlProxy_27;
	public static String ReferlProxy_31;
	public static String ReferlProxy_32;
	public static String ReferlProxy_33;
	public static String ReferlProxy_34;
	public static String ReferlProxy_35;
	public static String ReferlProxy_36;
	public static String ReferlProxy_37;
	public static String ReferlProxy_38;
	public static String ReferlProxy_39;
	public static String ReferlProxy_4;
	public static String ReferlProxy_40;
	public static String ReferlProxy_41;
	public static String ReferlProxy_45;
	public static String ReferlProxy_46;
	public static String ReferlProxy_48;
	public static String ReferlProxy_49;
	public static String ReferlProxy_50;
	public static String ReferlProxy_54;
	public static String ReferlProxy_55;
	public static String ReferlProxy_56;
	public static String ReferlProxy_57;
	public static String ReferlProxy_58;
	public static String ReferlProxy_59;
	public static String ReferlProxy_60;
	public static String ReferlProxy_61;
	public static String ReferlProxy_62;
	public static String ReferlProxy_65;
	public static String ReferlProxy_66;
	public static String ReferlProxy_67;
	public static String ReferlProxy_68;
	public static String ReferlProxy_69;
	public static String ReferlProxy_70;
	public static String ReferlProxy_71;
	static {
		// initialize resource bundle
		NLS.initializeMessages(BUNDLE_NAME, Messages.class);
	}

	private Messages() {
	}
}
