/* 
-*- coding: latin-1 -*-

This file is part of RefactorErl.

RefactorErl is free software: you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published
by the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

RefactorErl is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License
along with RefactorErl.  If not, see <http://plc.inf.elte.hu/erlang/>.

The Original Code is RefactorErl.

The Initial Developer of the Original Code is Eötvös Loránd University.
Portions created  by Eötvös Loránd University and ELTE-Soft Ltd.
are Copyright 2007-2024 Eötvös Loránd University, ELTE-Soft Ltd.
and Ericsson Hungary. All Rights Reserved.
*/

package com.refactorerl.ui.communication.exceptions;

/**
 * Should be thrown when the RefactorErl server signals that it processed our
 * request but won't serve it, because it couldn't acquire a read-write-lock for
 * the operation, ie. it was running a modifier operation already, or it was
 * running a non-modifier operation and the request sent would have been a
 * modifier operation.
 * 
 * @author Daniel Lukacs, 2014 ELTE IK
 *
 */
public class DeniedRequestException extends CommunicationException {
	private static final long serialVersionUID = -3161338092227695258L;

	public DeniedRequestException(String s) {
		super(s);

	}

}
